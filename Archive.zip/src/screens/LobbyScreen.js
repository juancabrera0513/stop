// src/screens/LobbyScreen.js
import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useGame } from "../context/GameContext";

export default function LobbyScreen({ navigation }) {
  const { players, roomConfig, startGame } = useGame();

  const onStart = () => {
    startGame();
    navigation.replace("Game");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Lobby (local)</Text>
      <Text style={styles.subtitle}>
        Rondas: {roomConfig?.rounds ?? "?"} – Modo: Clásico
      </Text>

      <View style={styles.list}>
        {players.map((p) => (
          <View key={p.id} style={styles.playerRow}>
            <Text style={styles.playerName}>{p.name}</Text>
          </View>
        ))}
      </View>

      <TouchableOpacity style={styles.btn} onPress={onStart}>
        <Text style={styles.btnText}>Iniciar partida</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 16 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 8 },
  subtitle: { fontSize: 14, marginBottom: 16 },
  list: {
    marginBottom: 24,
  },
  playerRow: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderColor: "#eee",
  },
  playerName: { fontSize: 16 },
  btn: {
    backgroundColor: "#2563eb",
    paddingVertical: 14,
    borderRadius: 999,
  },
  btnText: { color: "#fff", textAlign: "center", fontSize: 16 },
});
