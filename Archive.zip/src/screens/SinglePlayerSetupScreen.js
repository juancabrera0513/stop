// src/screens/SinglePlayerSetupScreen.js
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
} from "react-native";
import { useGame } from "../context/GameContext";

export default function SinglePlayerSetupScreen({ navigation }) {
  const { startSinglePlayer } = useGame();
  const [playerName, setPlayerName] = useState("Juan");
  const [rounds, setRounds] = useState("5");
  const [difficulty, setDifficulty] = useState("easy");

  const onStart = () => {
    const r = parseInt(rounds || "5", 10);
    if (isNaN(r) || r <= 0) {
      alert("Pon un número de rondas válido");
      return;
    }

    startSinglePlayer({
      playerName,
      rounds: r,
      difficultyLevel: difficulty,
    });

    // Ahora vamos a la pantalla de introducción de ronda,
    // NO directo al juego.
    navigation.replace("RoundIntro");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Configuración 1 jugador vs CPU</Text>

      <Text style={styles.label}>Tu nombre</Text>
      <TextInput
        style={styles.input}
        value={playerName}
        onChangeText={setPlayerName}
        placeholder="Tu nombre"
      />

      <Text style={styles.label}>Rondas</Text>
      <TextInput
        style={styles.input}
        value={rounds}
        onChangeText={setRounds}
        keyboardType="numeric"
        placeholder="5"
      />

      <Text style={styles.label}>Dificultad</Text>
      <View style={styles.diffRow}>
        <DiffButton
          label="Fácil"
          value="easy"
          current={difficulty}
          onChange={setDifficulty}
        />
        <DiffButton
          label="Normal"
          value="medium"
          current={difficulty}
          onChange={setDifficulty}
        />
        <DiffButton
          label="Difícil"
          value="hard"
          current={difficulty}
          onChange={setDifficulty}
        />
      </View>

      <TouchableOpacity style={styles.btnStart} onPress={onStart}>
        <Text style={styles.btnText}>Empezar partida</Text>
      </TouchableOpacity>
    </View>
  );
}

function DiffButton({ label, value, current, onChange }) {
  const active = current === value;
  return (
    <TouchableOpacity
      style={[styles.diffButton, active && styles.diffButtonActive]}
      onPress={() => onChange(value)}
    >
      <Text style={[styles.diffText, active && styles.diffTextActive]}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingVertical: 32,
    backgroundColor: "#f9fafb",
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 24,
    color: "#111827",
  },
  label: {
    fontSize: 14,
    fontWeight: "500",
    marginBottom: 4,
    color: "#374151",
  },
  input: {
    borderWidth: 1,
    borderColor: "#d1d5db",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    backgroundColor: "#ffffff",
    marginBottom: 16,
  },
  diffRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 8,
    marginBottom: 24,
  },
  diffButton: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#d1d5db",
    backgroundColor: "#ffffff",
    alignItems: "center",
  },
  diffButtonActive: {
    backgroundColor: "#2563eb",
    borderColor: "#2563eb",
  },
  diffText: {
    fontSize: 14,
    color: "#374151",
  },
  diffTextActive: {
    color: "#ffffff",
    fontWeight: "600",
  },
  btnStart: {
    backgroundColor: "#16a34a",
    paddingVertical: 14,
    borderRadius: 999,
    marginTop: 8,
  },
  btnText: {
    color: "#ffffff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
  },
});
