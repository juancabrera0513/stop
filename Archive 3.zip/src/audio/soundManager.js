// src/audio/soundManager.js
import { Audio } from "expo-av";
import { Vibration, Platform } from "react-native";

// 🎧 SFX cortos
const SFX_FILES = {
  uiOpen: require("../../assets/sounds/ui-open.mp3"),
  uiClick: require("../../assets/sounds/ui-click.mp3"),
  roundStart: require("../../assets/sounds/round-start.mp3"),
  stopHuman: require("../../assets/sounds/stop-human.mp3"),
  timeAlmost: require("../../assets/sounds/time-almost.mp3"),
  gameWin: require("../../assets/sounds/game-win.mp3"),
  roundLose: require("../../assets/sounds/round-lose.mp3"),
};

// 🎵 Música de fondo
const MUSIC_FILES = {
  menu: require("../../assets/sounds/music-menu.mp3"),
  round: require("../../assets/sounds/music-round.mp3"),
};

let currentMusicSound = null;
let currentMusicName = null;
let audioModeConfigured = false;

// ⚙️ Config básica de audio (sin interruptionModeIOS raro)
async function ensureAudioMode() {
  if (audioModeConfigured) return;

  try {
    await Audio.setAudioModeAsync({
      playsInSilentModeIOS: true,   // que suene aunque el iPhone esté en silencio
      staysActiveInBackground: false,
      shouldDuckAndroid: true,
    });
    audioModeConfigured = true;
  } catch (err) {
    console.warn("Error configurando Audio mode:", err);
  }
}

// 🔊 Efectos de sonido
export async function playSfx(
  name,
  { enabled = true, vibration = false } = {}
) {
  if (!enabled) return;

  const file = SFX_FILES[name];
  if (!file) return;

  try {
    await ensureAudioMode();

    const { sound } = await Audio.Sound.createAsync(file, {
      shouldPlay: true,
    });

    sound.setOnPlaybackStatusUpdate((status) => {
      if (status.didJustFinish || status.isLoaded === false) {
        sound.unloadAsync();
      }
    });
  } catch (err) {
    console.warn("Error reproduciendo SFX", name, err);
  }

  if (vibration) {
    const duration = Platform.OS === "ios" ? 50 : 30;
    Vibration.vibrate(duration);
  }
}

// 🎵 Música de fondo
export async function playMusic(
  name,
  { enabled = true, loop = true } = {}
) {
  if (!enabled) return;

  const file = MUSIC_FILES[name];
  if (!file) return;

  try {
    await ensureAudioMode();

    // Si ya está sonando esa misma pista, no hagas nada
    if (currentMusicSound && currentMusicName === name) {
      return;
    }

    // Cortar música anterior (si existe)
    if (currentMusicSound) {
      try {
        await currentMusicSound.stopAsync();
      } catch (e) {
        // ignore
      }
      try {
        await currentMusicSound.unloadAsync();
      } catch (e) {
        // ignore
      }
      currentMusicSound = null;
      currentMusicName = null;
    }

    const { sound } = await Audio.Sound.createAsync(file, {
      shouldPlay: true,
      isLooping: loop,
    });

    currentMusicSound = sound;
    currentMusicName = name;
    console.log("▶️ Reproduciendo música:", name);
  } catch (err) {
    console.warn("Error reproduciendo música", name, err);
  }
}

export async function stopMusic() {
  if (!currentMusicSound) return;

  try {
    await currentMusicSound.stopAsync();
    await currentMusicSound.unloadAsync();
  } catch (err) {
    console.warn("Error parando música", err);
  } finally {
    currentMusicSound = null;
    currentMusicName = null;
  }
}
