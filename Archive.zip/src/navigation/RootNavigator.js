// src/navigation/RootNavigator.js
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import HomeScreen from "../screens/HomeScreen";
import SinglePlayerSetupScreen from "../screens/SinglePlayerSetupScreen";
import RoundIntroScreen from "../screens/RoundIntroScreen";
import GameScreen from "../screens/GameScreen";
import RoundResultsScreen from "../screens/RoundResultsScreen";
import FinalResultsScreen from "../screens/FinalResultsScreen";

const Stack = createNativeStackNavigator();

export default function RootNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: "STOP – Inicio" }}
      />
      <Stack.Screen
        name="SinglePlayerSetup"
        component={SinglePlayerSetupScreen}
        options={{ title: "1 Jugador vs CPU" }}
      />
      <Stack.Screen
        name="RoundIntro"
        component={RoundIntroScreen}
        options={{ title: "Preparar ronda" }}
      />
      <Stack.Screen
        name="Game"
        component={GameScreen}
        options={{ title: "Ronda" }}
      />
      <Stack.Screen
        name="RoundResults"
        component={RoundResultsScreen}
        options={{ title: "Resultados de ronda" }}
      />
      <Stack.Screen
        name="FinalResults"
        component={FinalResultsScreen}
        options={{ title: "Resultados finales" }}
      />
    </Stack.Navigator>
  );
}
