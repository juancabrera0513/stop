// src/screens/HomeScreen.js
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ImageBackground,
} from "react-native";

export default function HomeScreen({ navigation }) {
  return (
    <ImageBackground
      source={require("../../assets/images/stop-bg.png")} // 👈 cambia aquí si usas otra imagen
      style={styles.bg}
      imageStyle={styles.bgImage}
    >
      <View style={styles.overlay}>
        <Text style={styles.title}>STOP – Juego de palabras</Text>
        <Text style={styles.subtitle}>
          Versión 1 jugador vs CPU (MVP funcional)
        </Text>

        <TouchableOpacity
          style={styles.btnPrimary}
          onPress={() => navigation.navigate("SinglePlayerSetup")}
        >
          <Text style={styles.btnText}>Jugar 1 jugador vs CPU</Text>
        </TouchableOpacity>

        {/* Futuro: botón para multijugador online */}
        {/* <TouchableOpacity style={styles.btnSecondary} disabled>
          <Text style={styles.btnTextSecondary}>
            Multijugador online (próximamente)
          </Text>
        </TouchableOpacity> */}

        <View style={styles.bannerPlaceholder}>
          <Text style={styles.bannerText}>
            Aquí iría el banner de publicidad (fijo en el menú)
          </Text>
        </View>
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  bg: {
    flex: 1,
  },
  bgImage: {
    resizeMode: "cover",
  },
  overlay: {
    flex: 1,
    padding: 16,
    justifyContent: "center",
    backgroundColor: "rgba(15,23,42,0.45)", // 👈 capa oscura encima de la imagen
  },
  title: {
    fontSize: 26,
    fontWeight: "900",
    textAlign: "center",
    marginBottom: 8,
    color: "#FFFFFF",
  },
  subtitle: {
    fontSize: 14,
    textAlign: "center",
    marginBottom: 24,
    color: "#E5E7EB",
  },
  btnPrimary: {
    backgroundColor: "#2563EB",
    paddingVertical: 14,
    borderRadius: 999,
    marginBottom: 12,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  btnText: { color: "#fff", textAlign: "center", fontSize: 16, fontWeight: "600" },
  btnSecondary: {
    backgroundColor: "#e5e7eb",
    paddingVertical: 14,
    borderRadius: 999,
    marginBottom: 12,
  },
  btnTextSecondary: { color: "#4b5563", textAlign: "center", fontSize: 16 },
  bannerPlaceholder: {
    marginTop: 40,
    alignItems: "center",
    padding: 8,
    borderWidth: 1,
    borderStyle: "dashed",
    borderRadius: 8,
    borderColor: "rgba(249,250,251,0.7)",
    backgroundColor: "rgba(15,23,42,0.5)",
  },
  bannerText: { fontSize: 12, opacity: 0.8, textAlign: "center", color: "#E5E7EB" },
});
