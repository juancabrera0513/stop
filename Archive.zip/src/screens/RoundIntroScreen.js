// src/screens/RoundIntroScreen.js
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
} from "react-native";
import { useGame } from "../context/GameContext";

export default function RoundIntroScreen({ navigation }) {
  const {
    player,
    bot,
    roundNumber,
    totalRounds,
    currentLetter,
    categories,
    difficulty,
  } = useGame();

  const handleStartRound = () => {
    // El contexto YA tiene la ronda preparada (letra, categorías, etc.)
    // Solo navegamos a la pantalla de juego donde arranca el timer.
    navigation.replace("Game");
  };

  if (!player || !bot || !currentLetter) {
    return (
      <View style={styles.center}>
        <Text style={styles.textCenter}>
          Preparando la partida...
        </Text>
      </View>
    );
  }

  const difficultyLabel =
    difficulty === "hard"
      ? "Difícil"
      : difficulty === "medium"
      ? "Normal"
      : "Fácil";

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Ronda {roundNumber} de {totalRounds}</Text>
      <Text style={styles.subtitle}>Letra</Text>
      <Text style={styles.letter}>{currentLetter}</Text>

      <View style={styles.vsBox}>
        <Text style={styles.vsText}>
          {player.name}{" "}
          <Text style={styles.vsHighlight}>vs</Text>{" "}
          {bot.name}
        </Text>
        <Text style={styles.diffText}>Dificultad: {difficultyLabel}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Categorías de esta ronda</Text>
        {categories.map((cat) => (
          <Text key={cat} style={styles.categoryItem}>
            • {cat}
          </Text>
        ))}
      </View>

      <TouchableOpacity style={styles.btnStart} onPress={handleStartRound}>
        <Text style={styles.btnText}>Comenzar ronda</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 24,
    paddingVertical: 32,
    backgroundColor: "#f9fafb",
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#f9fafb",
  },
  textCenter: {
    fontSize: 16,
    color: "#4b5563",
  },
  title: {
    fontSize: 22,
    fontWeight: "700",
    color: "#111827",
    marginBottom: 12,
  },
  subtitle: {
    fontSize: 14,
    color: "#6b7280",
  },
  letter: {
    fontSize: 64,
    fontWeight: "800",
    marginTop: 4,
    marginBottom: 16,
    color: "#111827",
  },
  vsBox: {
    padding: 12,
    borderRadius: 12,
    backgroundColor: "#111827",
    marginBottom: 20,
  },
  vsText: {
    fontSize: 16,
    color: "#f9fafb",
    fontWeight: "600",
    textAlign: "center",
  },
  vsHighlight: {
    color: "#f97316",
  },
  diffText: {
    marginTop: 4,
    fontSize: 13,
    color: "#e5e7eb",
    textAlign: "center",
  },
  card: {
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    backgroundColor: "#ffffff",
    padding: 16,
    marginBottom: 24,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: "600",
    marginBottom: 8,
    color: "#111827",
  },
  categoryItem: {
    fontSize: 14,
    color: "#374151",
    marginBottom: 4,
  },
  btnStart: {
    backgroundColor: "#16a34a",
    paddingVertical: 14,
    borderRadius: 999,
  },
  btnText: {
    color: "#ffffff",
    textAlign: "center",
    fontSize: 16,
    fontWeight: "600",
  },
});
