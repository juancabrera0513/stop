// src/screens/CreateRoomScreen.js
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
} from "react-native";
import { useGame } from "../context/GameContext";

export default function CreateRoomScreen({ navigation }) {
  const { createLocalRoom } = useGame();
  const [rounds, setRounds] = useState("5");
  const [player1, setPlayer1] = useState("Jugador 1");
  const [player2, setPlayer2] = useState("Jugador 2");
  const [player3, setPlayer3] = useState("");
  const [player4, setPlayer4] = useState("");
  const [player5, setPlayer5] = useState("");

  const onCreate = () => {
    const r = parseInt(rounds || "5", 10);
    const names = [player1, player2, player3, player4, player5].filter(
      (n) => n && n.trim().length > 0
    );
    if (names.length < 2) {
      alert("Necesitas al menos 2 jugadores.");
      return;
    }
    createLocalRoom({ rounds: r, playerNames: names });
    navigation.replace("Lobby");
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>Configurar partida local</Text>

      <Text style={styles.label}>Rondas</Text>
      <TextInput
        style={styles.input}
        value={rounds}
        onChangeText={setRounds}
        keyboardType="number-pad"
        placeholder="5"
      />

      <Text style={styles.label}>Jugadores (en el mismo dispositivo)</Text>
      <TextInput
        style={styles.input}
        value={player1}
        onChangeText={setPlayer1}
        placeholder="Jugador 1"
      />
      <TextInput
        style={styles.input}
        value={player2}
        onChangeText={setPlayer2}
        placeholder="Jugador 2"
      />
      <TextInput
        style={styles.input}
        value={player3}
        onChangeText={setPlayer3}
        placeholder="Jugador 3 (opcional)"
      />
      <TextInput
        style={styles.input}
        value={player4}
        onChangeText={setPlayer4}
        placeholder="Jugador 4 (opcional)"
      />
      <TextInput
        style={styles.input}
        value={player5}
        onChangeText={setPlayer5}
        placeholder="Jugador 5 (opcional)"
      />

      <TouchableOpacity style={styles.btn} onPress={onCreate}>
        <Text style={styles.btnText}>Crear y continuar</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 16,
  },
  title: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 24,
  },
  label: {
    fontSize: 14,
    marginBottom: 4,
    marginTop: 12,
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
  },
  btn: {
    backgroundColor: "#16a34a",
    paddingVertical: 14,
    borderRadius: 999,
    marginTop: 24,
  },
  btnText: { color: "#fff", textAlign: "center", fontSize: 16 },
});
