// src/screens/FinalResultsScreen.js
import React from "react";
import {
  ImageBackground,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import { useGame } from "../context/GameContext";

export default function FinalResultsScreen({ navigation }) {
  const {
    players,
    roundHistory,
    resetGame,
    computePlayerStats,
  } = useGame();

  if (!players || players.length === 0) {
    return (
      <View style={styles.center}>
        <Text style={styles.textCenter}>No hay datos para mostrar.</Text>
      </View>
    );
  }

  // 🔥 ESTO ES SEGURO: siempre devuelve objeto válido con todos los players
  const stats = computePlayerStats(players, roundHistory);

  // 🔥 Ordenar jugadores defendiendo stats indefinidos
  const safeTotal = (id) => (stats[id]?.total ?? 0);

  const sortedPlayers = [...players].sort(
    (a, b) => safeTotal(b.id) - safeTotal(a.id)
  );

  const winner = sortedPlayers[0];

  const handlePlayAgain = () => {
    resetGame();
    navigation.navigate("SinglePlayerSetup");
  };

  const handleSuddenDeath = () => {
    navigation.navigate("SinglePlayerSetup");
  };

  return (
    <ImageBackground
      source={require("../../assets/images/bg-home.png")}
      resizeMode="cover"
      style={{ flex: 1 }}
    >
      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.title}>Resultado Final</Text>

        {/* GANADOR */}
        <View style={styles.winnerCard}>
          <Text style={styles.winnerLabel}>Ganador</Text>
          <Text style={styles.winnerName}>{winner.name}</Text>
          <Text style={styles.winnerScore}>{safeTotal(winner.id)} pts</Text>
        </View>

        {/* LISTA DE JUGADORES */}
        <View style={styles.listContainer}>
          {sortedPlayers.map((p, index) => (
            <View key={p.id} style={styles.playerRow}>
              <Text style={styles.playerIndex}>{index + 1}.</Text>
              <Text style={styles.playerName}>{p.name}</Text>
              <Text style={styles.playerScore}>{safeTotal(p.id)} pts</Text>
            </View>
          ))}
        </View>

        {/* BOTONES */}
        <TouchableOpacity style={styles.btnPrimary} onPress={handlePlayAgain}>
          <Text style={styles.btnPrimaryText}>Jugar de nuevo</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.btnSecondary} onPress={handleSuddenDeath}>
          <Text style={styles.btnSecondaryText}>Sudden Death</Text>
        </TouchableOpacity>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    paddingTop: 120,
    alignItems: "center",
  },
  title: {
    fontSize: 32,
    color: "#fff",
    fontWeight: "800",
    marginBottom: 16,
    textAlign: "center",
  },
  winnerCard: {
    width: "90%",
    backgroundColor: "rgba(255,255,255,0.15)",
    borderRadius: 16,
    padding: 20,
    alignItems: "center",
    marginBottom: 24,
  },
  winnerLabel: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
  },
  winnerName: {
    color: "#fff",
    fontSize: 28,
    fontWeight: "700",
    marginTop: 4,
  },
  winnerScore: {
    color: "#fff",
    marginTop: 6,
    fontSize: 20,
    fontWeight: "600",
  },
  listContainer: {
    width: "100%",
    marginBottom: 30,
    paddingHorizontal: 12,
  },
  playerRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: "rgba(255,255,255,0.15)",
  },
  playerIndex: {
    color: "#fff",
    fontWeight: "700",
  },
  playerName: {
    color: "#fff",
    fontSize: 16,
  },
  playerScore: {
    color: "#fff",
    fontWeight: "600",
  },
  btnPrimary: {
    width: "90%",
    backgroundColor: "#ffffff",
    paddingVertical: 14,
    borderRadius: 999,
    marginBottom: 12,
  },
  btnPrimaryText: {
    textAlign: "center",
    color: "#111827",
    fontWeight: "700",
    fontSize: 16,
  },
  btnSecondary: {
    width: "90%",
    paddingVertical: 13,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: "#ffffff",
  },
  btnSecondaryText: {
    textAlign: "center",
    color: "#fff",
    fontWeight: "600",
    fontSize: 14,
  },
  center: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  textCenter: {
    color: "#fff",
    fontSize: 18,
  },
});
